using Project_mod3_Lib;

namespace ProjectApp_mod3;
/// <summary>
/// Класс, реализующий все выполнение программы.
/// </summary>
public class MenuManager
{
    private RecipeManager _recipeManager;
    
    /// <summary>
    /// Конструктор класса MenuManager. 
    /// </summary>
    public MenuManager()
    {
        _recipeManager = new RecipeManager();
    }
    /// <summary>
    /// Главное меню. 
    /// </summary>
    public void MainMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Для выбора действия введите соответствующий номер");
            Console.WriteLine();
            Console.WriteLine("1. Ввести данные (в консоль или из файла)");
            Console.WriteLine("2. Отфильтровать данные");
            Console.WriteLine("3. Отсортировать данные");
            Console.WriteLine("4. Получить данные о процессе выполения и результатах рецепта по id");
            Console.WriteLine("5. Конвертация данных в Excel-таблицу или извлечение данных из Excel-таблицы");
            Console.WriteLine("6. Вывести данные (в консоль или в файл)");
            Console.WriteLine("7. Выход из программы");
            var input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    Menu1();
                    break;
                case "2":
                    Console.Clear();
                    Console.Write("Введите ключ для фильтрации: ");
                    var filterKey = Console.ReadLine();
                    Console.Write("Введите значения для фильтрации через запятую: ");
                    var value = Console.ReadLine();
                    var values = value?.Split(',').Select(v => v.Trim()).ToList();
                    if (values != null && filterKey != null)
                    {
                        Console.Write(_recipeManager.FilterData(values, filterKey));
                    }
                    EndMessage();
                    break;
                case "3":
                    Console.Clear();
                    Console.Write("Введите ключ для сортировки:");
                    var sortKey = Console.ReadLine()?.Trim();
                    Console.Write("Введите направление сортировки (asc/desc): ");
                    var asc = Console.ReadLine()?.Trim().ToLower() == "asc";
                    if (sortKey != null)
                    {
                        Console.Write(_recipeManager.SortData(sortKey, asc));
                    }
                    GreenMessage("Данные успешно отсортированы!");
                    EndMessage();
                    break;
                case "4":
                    Console.Clear();
                    Console.WriteLine("Введите id объекта, о котором хотите получить информацию");
                    var id = Console.ReadLine();
                    if (id != null)
                    {
                        Console.Write(_recipeManager.GetData(id));
                    }
                    EndMessage();
                    break;
                case "5":
                    Menu5();
                    break;
                case "6":
                    Console.Clear();
                    Menu6();
                    break;
                case "7":
                    Console.WriteLine("Программа успешно завершена");
                    return;
                default:
                    RedMessage("Некорректный ввод!");
                    EndMessage();
                    break;
            } 
        }
        
    }
    
    /// <summary>
    /// Меню для первого пункта основного меню (ввод в консоль или в файл).
    /// </summary>
    private void Menu1()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Для выбора действия введите соответствующий номер");
            Console.WriteLine();
            Console.WriteLine("0. Вернуться в меню");
            Console.WriteLine("1. Ввести данные в консоль");
            Console.WriteLine("2. Получить данные из файла");
            var input = Console.ReadLine();
            switch (input)
            {
                case "0":
                    return;
                case "1":
                    Console.Clear();
                    Console.WriteLine("Введите данные (для окончания ввода введите END)");
                    input = string.Empty;
                    while (true)
                    {
                        var buf = Console.ReadLine();
                        if (buf == "END")
                        {
                            break;
                        }

                        input += buf;
                    }  
                    _recipeManager.Elements = JsonParser.ReadJson(input, false);
                    return;
                case "2":
                    Console.Clear();
                    Console.WriteLine("Введите полный путь к файлу");
                    var path = Console.ReadLine();
                    if (path != null)
                    {
                        _recipeManager.Elements = JsonParser.ReadJson(path);
                    }
                    return;
                default:
                    RedMessage("Некорректный ввод!");
                    EndMessage();
                    break;
            } 
        }    
        
    }

    /// <summary>
    /// Меню для шестого пункта основного меню (вывод в консоль или в файл).
    /// </summary>
    private void Menu6()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Для выбора действия введите соответствующий номер");
            Console.WriteLine();
            Console.WriteLine("0. Вернуться в меню");
            Console.WriteLine("1. Вывести данные в консоль");
            Console.WriteLine("2. Получить данные в файл");
            var input = Console.ReadLine();
            switch (input)
            {
                case "0":
                    return;   
                case "1":
                    Console.Clear();
                    foreach (Elem element in _recipeManager.Elements)
                    {
                        Console.WriteLine(element.ToString());
                    }
                    EndMessage();
                    return;
                case "2":
                    Console.Clear();
                    Console.WriteLine("Введите полный путь к файлу");
                    var path = Console.ReadLine();
                    if (path != null)
                    {
                        JsonParser.WriteJson(path, _recipeManager.ConvertToJson());
                    }
                    GreenMessage("Данные успешно загружены!");
                    EndMessage();
                    return;
                default:
                    RedMessage("Некорректный ввод!");
                    EndMessage();
                    break;
            } 
        }    
    }

    /// <summary>
    /// Меню для пятого пункта основного меню (экспорт в xlxs или импорт из xlxs). 
    /// </summary>
    private void Menu5()
    {
        Console.Clear();
        Console.WriteLine("0. Вернуться в меню");
        Console.WriteLine("1. Экспортировать данные в Excel");
        Console.WriteLine("2. Импортировать данные из Excel");
        var input = Console.ReadLine();
        switch (input)
        {
            case "0":
                return;
            case "1":
                Console.Write("Введите путь для экспорта данных из Excel-файла: ");
                var excelPath = Console.ReadLine();
                if (excelPath != null)
                {
                    _recipeManager.ConvertToExcel(excelPath);
                }
                EndMessage();
                return;
            case "2":
                Console.Write("Введите путь для импорта данных из Excel-файла: ");
                excelPath = Console.ReadLine();
                if (excelPath != null)
                {
                    _recipeManager.ConvertToExcel(excelPath, false);
                }
                EndMessage();
                return;
            default:
                RedMessage("Некорректный ввод");
                return;
        }
    }

    public void GreenMessage(string message)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(message);
        Console.ResetColor();
    }

    public void RedMessage(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ResetColor();
    }

    public void EndMessage()
    {
        Console.WriteLine("Нажмите любую клавишу для продолжения");
        Console.ReadKey();
    }
}