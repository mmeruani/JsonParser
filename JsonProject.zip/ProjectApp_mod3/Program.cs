﻿// Медведская Мария Ильинична. 
// БПИ-246-2. 
// Вариант 2. 
namespace ProjectApp_mod3;
using System.Security;
using System.Xml;

public class Program
{
    /// <summary>
    /// Точка входа в программу.
    /// </summary>
    public static void Main()
    {
        MenuManager manager = new MenuManager();
        while (true)
        {
            bool isEnd = false;
            try
            {
                manager.MainMenu();
                isEnd = true;
            }
            catch (OutOfMemoryException e)
            {
                Console.WriteLine("Ошибка памяти" + e.Message);
            }
            catch (UnauthorizedAccessException e)
            {
                Console.WriteLine("Ошибка доступа: " + e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine("Ошибка ввода-вывода: " + e.Message);
            }
            catch (SecurityException e)
            {
                Console.WriteLine("Ошибка безопасности: " + e.Message);
            }
            catch (FormatException e)
            {
                Console.WriteLine("Ошибка формата данных: " + e.Message);
            }
            catch (XmlException e)
            {
                Console.WriteLine("Ошибка обработки XML: " + e.Message);
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine("Ошибка: передан null-значение. " + e.Message);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("Ошибка: недопустимый аргумент. " + e.Message);
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("Ошибка: выход за границы массива или списка. " + e.Message);
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine("Ошибка: недопустимая операция. " + e.Message);
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine("Ошибка: обращение к null-объекту. " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Неизвестная ошибка: " + e.Message);
            }

            if (isEnd) return; // Маркер завершения программы (обход Exception). 
            
            Console.WriteLine("Нажмите любую клавишу для продолжения");
            Console.ReadKey();
        }
    }
} 