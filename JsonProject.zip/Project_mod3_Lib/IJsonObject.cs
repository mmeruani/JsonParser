﻿namespace Project_mod3_Lib;

/// <summary>
/// Интерфейс для объектов, работающих с JSON.
/// Определяет методы для получения и установки полей объектов.
/// </summary>
public interface IJsonObject
{
    /// <summary>
    /// Получает список всех доступных полей объекта.
    /// </summary>
    IEnumerable<string> GetAllFields();  

    /// <summary>
    /// Получает значение указанного поля объекта.
    /// </summary>
    /// <param name="fieldName">Название поля.</param>
    /// <returns>Значение поля в виде строки.</returns>
    string GetField(string fieldName);  

    /// <summary>
    /// Устанавливает значение указанного поля объекта.
    /// </summary>
    /// <param name="fieldName">Название поля.</param>
    /// <param name="value">Новое значение поля.</param>
    void SetField(string fieldName, string value);  
}