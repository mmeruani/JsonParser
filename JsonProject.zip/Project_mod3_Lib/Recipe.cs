namespace Project_mod3_Lib;

/// <summary>
/// Структура объекта типа Recipe. 
/// </summary>
public struct Recipe
{
    public List<Pair<string, string>> Str;
    public int StrSize;
    public List<Pair<string, List<Pair<string, string>>>> StrLists;
    public int StrListsSize;
    public List<Pair<string, List<List<Pair<string, string>>>>> StrListLists;
    public int StrListListsSize;
    public Recipe() => (Str, StrLists, StrListLists, StrSize, StrListsSize, StrListListsSize) = (new List<Pair<string, string>>(), new List<Pair<string, List<Pair<string, string>>>>(), new List<Pair<string,List<List<Pair<string, string>>>>>(), 0, 0, 0);

    /// <summary>
    /// Получает список всех доступных полей объекта.
    /// </summary>
    public string GetField(string fieldName)
    {
        foreach (Pair<string, string> str in Str)
        {
            if (str.First == fieldName)
            {
                return str.Second;
            }
        }

        return string.Empty;
    }
    
    /// <summary>
    /// Получает значение указанного поля объекта.
    /// </summary>
    /// <param name="fieldName">Название поля.</param>
    /// <returns>Значение поля в виде строки.</returns>
    public void SetField(string fieldName, string value)
    {
        int res = 0;
        for (int i = 0; i < Str.Count; i++)
        {
            if (Str[i].First == fieldName)
            {
                Str[i].SecondSet(value);
                res = 1;
            }    
        }

        if (res == 0)
        {
            for (int i = 0; i < StrLists.Count; i++)
            {
                if (StrLists[i].First == fieldName)
                {
                    res = 2;
                }    
            }
        }

        if (res == 0)
        {
            for (int i = 0; i < StrListLists.Count; i++)
            {
                if (StrListLists[i].First == fieldName)
                {
                    res = 2;
                }    
            }
        }

        if (res == 0)
        {
            Console.WriteLine("Такое поле не найдено");
            Console.WriteLine("Нажмите любую клавишу для продолжения");
            Console.ReadKey();
        }
        if (res == 1)
        {
            Console.WriteLine("Поле успешно изменено");
            Console.WriteLine("Нажмите любую клавишу для продолжения");
            Console.ReadKey();
        }
        if (res == 2)
        {
            Console.WriteLine("Это поле нельзя изменить");
            Console.WriteLine("Нажмите любую клавишу для продолжения");
            Console.ReadKey();
        }
    }
   
    /// <summary>
    /// Преобразование объекта Recipe для вывода в json формате. 
    /// </summary>
    /// <returns> Строка - результат вывода. </returns>
    public override string ToString()
    {
        string res = String.Empty;
        res += ToString(Str);
        if (StrListsSize > 0)
        {
            
            if(res != "") res += ",\n";
            for (int i = 0; i < StrListsSize; ++i)
            {
                res += "\"" + StrLists[i].First + "\"" + ": {";
                res += ToString(StrLists[i].Second);
                if (i != StrListsSize - 1) res += "},\n";
                else res += "}\n";
            }
        }
        if (StrListListsSize > 0)
        {
            if(res != "") res += ",\n";
            for (int i = 0; i < StrListListsSize; ++i)
            {
                res += "\"" + StrListLists[i].First + "\"" + ": [\n";
                for (int j = 0; j < StrListLists[i].Second.Count; ++j)
                {
                    res += "{";
                    res += ToString(StrListLists[i].Second[j]);
                    if (j != StrListLists[i].Second.Count - 1) res +=  "},\n";
                    else res += "}";
                }
                res += "\n]\n";
            }
        }

        return res;
    }

    /// <summary>
    /// ToString-помощник. 
    /// </summary>
    /// <param name="list"> Список объектов типа Pair(string, string). </param>
    /// <returns> Строку - результат преобразования. </returns>
    private string ToString(List<Pair<string, string>> list)
    {
        if (list.Count == 0) return String.Empty;
        string res = "\n";
        for (int i = 0; i < list.Count; ++i)
        {
            if (i != list.Count - 1) res += $"\"{list[i].First}\": \"{list[i].Second}\", \n";
            else res += $"\"{list[i].First}\": \"{list[i].Second}\" \n";
        }
        return res;
    }
}