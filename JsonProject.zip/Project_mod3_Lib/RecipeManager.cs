namespace Project_mod3_Lib;
using ClosedXML.Excel;

/// <summary>
/// Класс, реализующий функциональное выполнение пунктов меню (работает с объектами Recipe). 
/// </summary>
public class RecipeManager
{
    private List<Elem> _elements;

    public List<Elem> Elements { get => _elements; set => _elements = value; }

    /// <summary>
    /// Конструктор класса RecipeManager. 
    /// </summary>
    public RecipeManager() => Elements = new List<Elem>(); // Нет смысла инициализировать _elements тут. 
    
    /// <summary>
    /// 2. Отправляет запрос фильтрацию объектов по полю и значению(-ям) и обрабатывает его.  
    /// </summary>
    /// <param name="filters"> Значения полей для выборки. </param>
    /// <param name="filterField"> Поле для фильтрации. </param>
    /// <returns> Текст - все объекты после фильтрации. </returns>
    public string FilterData(List<string> filters, string filterField)
    {
        string result = string.Empty;
        List<Elem> filtered = new List<Elem>();
        foreach (var elem in _elements)
        {
            if (elem.FilterData(filters, filterField))
            {
                filtered.Add(elem);
            }
        }

        foreach (Elem elem in filtered)
        {
            result+=elem.ToString();
        }
        return result;
    }
    
    /// <summary>
    /// 3. Сортировка объектов по возрастанию или убыванию. 
    /// </summary>
    /// <param name="key"> Значение, по которому реализовывать сортировку. </param>
    /// <param name="sortAscending"> Возрастание/убывание. </param>
    /// <returns> Текст - все объекты после сортировки.</returns>
    public string SortData(string key, bool sortAscending)
    {
        string result = string.Empty;
        List<Elem> sorted = Elements = sortAscending
            ? Elements.OrderBy(f => f.GetField(key)).ToList()
            : Elements.OrderByDescending(f => f.GetField(key)).ToList();
        foreach (Elem elem in sorted)
        {
            result+=elem.ToString();
        }
        return result;
    }

    /// <summary>
    /// 4. Отправляет запрос на вывод данных о конкретном объекте по его id и обрабатывает его. 
    /// </summary>
    /// <param name="id"> id объекта. </param>
    /// <returns> Всю информацию об объекте. </returns>
    public string GetData(string id)
    {
        string result = string.Empty;
        foreach (Elem elem in _elements)
        {
            if (elem.GetData(id))
            {
                result = elem.ToString();
            }
        }
        return result;
    }

    /// <summary>
    /// Преобразование данных в форматированый текст для вывода в json формат. 
    /// </summary>
    /// <returns> Данные в формате json. </returns>
    public string ConvertToJson()
    {
        string result = String.Empty;
        result += "{\"recipes\":\n  [\n";

        for (int i = 0; i < Elements.Count(); ++i)
        {
            result += "{\n";
            result += Elements[i].ToString();
            if (i != Elements.Count() - 1) result += "},";
            else result += "}";
        }
        result += "  ]\n}";
        return result;
    }

    /// <summary>
    /// 5. Работа с файлами типа xlsx, экспорт данных в таблицу Excel и импорт из таблицы Excel. 
    /// </summary>
    /// <param name="filePath"> Путь к файлу для экспорта/импорта. </param>
    /// <param name="export"> Выбор пользователя (экспорт/импорт) </param>
    public void ConvertToExcel(string filePath, bool export  = true)
    {
        if (export)
        {
           using (XLWorkbook workbook = new XLWorkbook())
           {
               var worksheet = workbook.Worksheets.Add("Recipes");
   
               if (_elements.Count == 0)
               {
                   Console.WriteLine("Нет данных для экспорта.");
                   return;
               }
               
               HashSet<string> headers = new HashSet<string>();
               foreach (Elem elem in _elements)
               {
                   foreach (string field in elem.GetAllFields())
                   {
                       headers.Add(field);
                   }
               }
   
               List<string> headerList = new List<string>(headers);
               for (int col = 0; col < headerList.Count; col++)
               {
                   worksheet.Cell(1, col + 1).Value = headerList[col];
                   worksheet.Cell(1, col + 1).Style.Fill.BackgroundColor = XLColor.LightGray; // Подкрашивание полей для заголовков полей. 
               }

               int row = 2;
               foreach (Elem elem in _elements)
               {
                   for (int col = 0; col < headerList.Count; col++)
                   {
                       string fieldName = headerList[col];
                       if (elem.GetField(fieldName) != string.Empty)
                       {
                           string value = elem.GetField(fieldName);
                           worksheet.Cell(row, col + 1).Value = value;
                           Console.WriteLine($"[{row}, {col + 1}] = {value}");
                       }
                   }
   
                   row++;
               }
               
               worksheet.Columns().AdjustToContents(); // Форматирование колонок по ширине. 
               
               workbook.SaveAs(filePath);
               Console.ForegroundColor = ConsoleColor.Green;
               Console.WriteLine("Данные успешно экспортированы в Excel: " + filePath);
               Console.ResetColor();
           } 
        }
        else
        {
            using (XLWorkbook workbook = new XLWorkbook(filePath))
            {
                var worksheet = workbook.Worksheet(1);
                var rows = worksheet.RowsUsed();
                
                List<string> headers = new List<string>();
                foreach (var cell in rows.First().Cells())
                {
                    headers.Add(cell.Value.ToString()); 
                }
                
                _elements = new List<Elem>();
                
                foreach (var row in rows.Skip(1))
                {
                    Elem elem = new Elem();
                    for (int col = 0; col < headers.Count; col++)
                    {
                        Pair<string, string> pair = new (headers[col],row.Cell(col + 1).Value.ToString()) ;
                        elem.AddStr(pair);
                    }
                    _elements.Add(elem);
                }
                
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Данные успешно импортированы из Excel: " + filePath);
                Console.ResetColor();
            }
        }
    }
}