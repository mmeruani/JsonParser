namespace Project_mod3_Lib;

/// <summary>
/// Класс,представляющий объект Recipe и унаследованный от IJsonObject. 
/// </summary>
public class Elem : IJsonObject
{
    /// <summary>
    /// Экземпляр класса Рецепт. 
    /// </summary>
    private Recipe _recipe;

    /// <summary>
    /// Конструктор класса Elem. 
    /// </summary>
    public Elem() => _recipe = new Recipe();

    /// <summary>
    /// Фильтрация объектов по полю и значению(-ям).  
    /// </summary>
    /// <param name="filters"> Значения полей для выборки. </param>
    /// <param name="filterField"> Поле для фильтрации. </param>
    /// <returns> Bool значение, отвечающее за нахождение объекта по полю. </returns>
    public bool FilterData(List<string> filters, string filterField)
    {
        foreach (string filter in filters)
        {
            foreach (Pair<string, string> str in _recipe.Str)
            {
                if (str.First == filterField && str.Second == filter)
                {
                    return true;
                }
            }
        }
        return false;
    }

    /// <summary>
    /// Вывод данных о конкретном объекте по его id. 
    /// </summary>
    /// <param name="id"> id объекта. </param>
    /// <returns> Всю информацию об объекте. </returns>
    public bool GetData(string id)
    {
        bool result = false;
        foreach (Pair<string, string> str in _recipe.Str)
        {
            if (str.Second == id)
            {
                result = true;
            }
        }
        return result;
    }
    
    /// <summary>
    /// Добавление нового элемента типа Pair(string, string). 
    /// </summary>
    /// <param name="pair"> Элемент. </param>
    public void AddStr(Pair<string, string> pair)
    {
        _recipe.Str.Add(pair);
        _recipe.StrSize += 1;
    }
    
    /// <summary>
    /// Добавление нового элемента типа Pair(string, List(Pair(string, string))).  
    /// </summary>
    /// <param name="pair"> Элемент. </param>
    public void AddStrLists(Pair<string, List<Pair<string, string>>> pair)
    {
        _recipe.StrLists.Add(pair);
        _recipe.StrListsSize += 1;
    }
    
    /// <summary>
    /// Добавление нового элемента типа Pair(string, List(List(Pair(string, string)))). 
    /// </summary>
    /// <param name="pair"> Элемент. </param>
    public void AddStrListLists(Pair<string, List<List<Pair<string, string>>>> pair)
    {
        _recipe.StrListLists.Add(pair);
        _recipe.StrListListsSize += 1;
    }
    
    /// <summary>
    /// Запрос вывода элемента recipe в формат строки. 
    /// </summary>
    /// <returns> Строка. </returns>
    public override string ToString()
    {
        return _recipe.ToString();
    }
    
    /// <summary>
    /// Получает список всех доступных полей объекта.
    /// </summary>
    public IEnumerable<string> GetAllFields()
    {
        List<string> res = new List<string>();
        for (int i = 0; i < _recipe.Str.Count; i++)
        {
            res.Add(_recipe.Str[i].First);
        }

        return res;
    }

    /// <summary>
    /// Получает значение указанного поля объекта.
    /// </summary>
    /// <param name="fieldName">Название поля.</param>
    /// <returns>Значение поля в виде строки.</returns>
    public string GetField(string fieldName)
    {
        return _recipe.GetField(fieldName);
    }

    /// <summary>
    /// Устанавливает значение указанного поля объекта.
    /// </summary>
    /// <param name="fieldName">Название поля.</param>
    /// <param name="value">Новое значение поля.</param>
    public void SetField(string fieldName, string value)
    {
        
        _recipe.SetField(fieldName, value); 
    }
}