namespace Project_mod3_Lib;

/// <summary>
/// Пара из двух элементов типа T1 и T2. 
/// </summary>
/// <typeparam name="T1"> Первый элемент. </typeparam>
/// <typeparam name="T2"> Второй элемент. </typeparam>
public struct Pair<T1, T2>
{
    public T1 First { get; set; }
    public T2 Second { get; set; }
    public Pair(T1 first, T2 second) => (First, Second) = (first, second);
    public void SecondSet(T2 second) => Second = second;
}