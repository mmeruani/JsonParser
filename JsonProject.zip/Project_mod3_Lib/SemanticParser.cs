namespace Project_mod3_Lib;

/// <summary>
/// Семантический парсер. 
/// </summary>
public class SemanticParser
{
   /// <summary>
   /// Список объектов элементов (рецептов). 
   /// </summary>
   private List<Elem> _result;
   
   /// <summary>
   /// Элемент (рецепт). 
   /// </summary>
   private Elem _elem;
   
   /// <summary>
   /// Строка, представляющая "поле":"значение".
   /// </summary>
   private Pair<string, string> _str;
   
   /// <summary>
   /// 
   /// </summary>
   private Pair<string, List<Pair<string, string>>> _strLists;
   private Pair<string, List<List<Pair<string, string>>>> _strListLists;
   
   /// <summary>
   /// Конструктор класса SemanticParser. 
   /// </summary>
   public SemanticParser()
   {
      _str = new Pair<string, string>();
      _strLists = new Pair<string, List<Pair<string, string>>>();
      _strLists.Second = new List<Pair<string, string>>();
      _strListLists = new Pair<string, List<List<Pair<string, string>>>>();
      _strListLists.Second = new List<List<Pair<string, string>>>();
      _elem = new Elem();
      _result = new List<Elem>();
   }

   /// <summary>
   /// Запуск семантического анализа. 
   /// </summary>
   /// <param name="input"> Текст для семантического анализа. </param>
   /// <returns> Список элементов (объектов Elem). </returns>
   public List<Elem> Parse(string input)
   {
      return SemAnalize(LexemeParse(input));
   }
   
   /// <summary>
   /// Парсинг лексем (разбиение данных на лексемы). 
   /// </summary>
   /// <param name="json"> Json данные. </param>
   /// <returns> Список лексем (объектов Node). </returns>
   private static List<Node> LexemeParse(string json)
   {
      List<Node> nodes = new List<Node>();
      json = json.Replace("\n", "").Replace("\r", "").Replace("\t", "");
      string now = string.Empty;
      bool isText = false;
      int isSlashPrev = 0;
      foreach (char ch in json)
      {
         if (ch == '\\')
         {
            isSlashPrev = 2;
         }
         if (ch == '"' && isSlashPrev == 0)
         {
            isText = !isText;
            if (now != string.Empty)
            {
               Node currentNode = new Node();
               currentNode.Text = now;
               currentNode.Type = "String";
               nodes.Add(currentNode);
               now = string.Empty;
            }
         }
         else if (isText)
         {
            now += ch;
         }
         else
         {
            if (ch == ' ') continue;
            if (now != string.Empty && (ch == '{' || ch == '}' || ch == '[' || ch == ']' || ch == ',' || ch == ':'))
            {
               Node currentNode = new Node();
               currentNode.Text = now;
               currentNode.Type = "String";
               nodes.Add(currentNode);
               now = string.Empty;
            }
            if (ch == '{')
            {
               Node currentNode = new Node();
               currentNode.Text = "{";
               currentNode.Type = "OpFigBrack";
               nodes.Add(currentNode);
            }
            else if (ch == '}')
            {
               Node currentNode = new Node();
               currentNode.Text = "}";
               currentNode.Type = "ClFigBrack";
               nodes.Add(currentNode);
            }
            else if (ch == '[')
            {
               Node currentNode = new Node();
               currentNode.Text = "[";
               currentNode.Type = "OpSqBrack";
               nodes.Add(currentNode);
            }
            else if (ch == ']')
            {
               Node currentNode = new Node();
               currentNode.Text = "]";
               currentNode.Type = "ClSqBrack";
               nodes.Add(currentNode);
            }
            else if (ch == ':')
            {
               Node currentNode = new Node();
               currentNode.Text = ":";
               currentNode.Type = "DoubleDot";
               nodes.Add(currentNode);
            }
            else if (ch == ',')
            {
               Node currentNode = new Node();
               currentNode.Text = ",";
               currentNode.Type = "Comma";
               nodes.Add(currentNode);
            }
            else
            {
               now += ch;
            }
         }
         isSlashPrev = isSlashPrev != 0 ? isSlashPrev - 1 : 0;
      } 
      return nodes;
   }
   /// <summary>
   /// Начало семантического анализа. 
   /// </summary>
   /// <param name="lexemes"> Список лексем (объектов Node) для анализа. </param>
   /// <returns> Список всех элементов (объектов Elem). </returns>
   /// <exception cref="Exception"> Проверка на корректность данных. </exception>
   private List<Elem> SemAnalize(List<Node> lexemes)
   {
      int n = 0;
      File(ref n, ref lexemes);
      if (n == lexemes.Count) return _result;
      else throw new Exception("Неожиданные лексемы после конца файла");
   } 
   /// <summary>
   /// Далее идущие блоки - реализация семантического анализа.
   /// Для каждого блока описывается его функция. 
   /// </summary>
   /// <param name="pos"> Позиция. </param>
   /// <param name="lexemes"> Список всех лексем. </param>
   
   // Семантический анализ всего файла. 
   private void File(ref int pos, ref List<Node> lexemes)
   {
      OpFigBrack(ref pos, ref lexemes);
      String(ref pos, ref lexemes);
      DoubleDot(ref pos, ref lexemes);
      OpSqBrack(ref pos, ref lexemes);
      if (lexemes[pos].Type != "ClSqBrack")
      {
         Blocks(ref pos, ref lexemes);
      }
      ClSqBrack(ref pos, ref lexemes);
      ClFigBrack(ref pos, ref lexemes);
   }
   
   // Анализ блоков. 
   private void Blocks(ref int pos, ref List<Node> lexemes)
   {
      Block(ref pos, ref lexemes);
      _result.Add(_elem);
      _elem = new Elem();
      NextBlock(ref pos, ref lexemes);
   }
   
   // Самовызывающийся помощник для анализа блоков. 
   private void NextBlock(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         Comma(ref pos, ref lexemes);
         Block(ref pos, ref lexemes);
         _result.Add(_elem);
         _elem = new Elem();
         NextBlock(ref pos, ref lexemes);
      }
   }
   
   // Анализ блока. 
   private void Block(ref int pos, ref List<Node> lexemes)
   {
      OpFigBrack(ref pos, ref lexemes);
      if(lexemes[pos].Type != "ClFigBrack") Elements(ref pos, ref lexemes);
      ClFigBrack(ref pos, ref lexemes);
   }
   
   // Анализ элементов. 
   private void Elements(ref int pos, ref List<Node> lexemes)
   {
      Element(ref pos, ref lexemes);
      NextElement(ref pos, ref lexemes);
   }
   
   // Самовызывающийся помощник для анализа элементов. 
   private void NextElement(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         Comma(ref pos, ref lexemes);
         Element(ref pos, ref lexemes);
         NextElement(ref pos, ref lexemes);
      }
   }
   
   // Анализ элемента. 
   private void Element(ref int pos, ref List<Node> lexemes)
   {
      string buf;
      String(ref pos, ref lexemes);
      buf = lexemes[pos-1].Text;
      DoubleDot(ref pos, ref lexemes);
      int type = Object(ref pos, ref lexemes);
      switch (type)
      {
         case 1:
            _str.First = buf;
            _elem.AddStr(_str);
            _str = new Pair<string, string>();
            break;
         case 2:
            _strLists.First = buf;
            _elem.AddStrLists(_strLists);
            _strLists = new Pair<string, List<Pair<string, string>>>();
            _strLists.Second = new List<Pair<string, string>>();
            break;
         case 3:
            _strListLists.First = buf;
            _elem.AddStrListLists(_strListLists);
            _strListLists = new Pair<string, List<List<Pair<string, string>>>>();
            _strListLists.Second = new List<List<Pair<string, string>>>();
            break;
         default:
            throw new Exception("В этот дефолт зайти нельзя :)");
      }
   }
   
   // Анализ значения поля элемента. 
   private int Object(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "String")
      {
         String(ref pos, ref lexemes);
         _str.Second = lexemes[pos - 1].Text;
         return 1;
      }
      if (lexemes[pos].Type == "OpFigBrack")
      {
         List(ref pos, ref lexemes);
         return 2;
      }
      else
      {
         Dict(ref pos, ref lexemes);
         return 3;
      }
   }
   
   // Анализ, если значение поля List. 
   private void List(ref int pos, ref List<Node> lexemes)
   {
      BlockForList(ref pos, ref lexemes);
   }
   
   // Анализ блока для List. 
   private void BlockForList(ref int pos, ref List<Node> lexemes)
   {
      OpFigBrack(ref pos, ref lexemes);
      if(lexemes[pos].Type != "ClFigBrack") ElementsForList(ref pos, ref lexemes); 
      ClFigBrack(ref pos, ref lexemes);
   }
   
   // Анализ элементов для List. 
   private void ElementsForList(ref int pos, ref List<Node> lexemes)
   {
      ElementForList(ref pos, ref lexemes);
      _strLists.Second.Add(_str);
      NextElementForList(ref pos, ref lexemes);
   }
   // Самовызывающийся помощник для анализа элементов в случае List. 
   private void NextElementForList(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         Comma(ref pos, ref lexemes);
         ElementForList(ref pos, ref lexemes);
         _strLists.Second.Add(_str);
         NextElementForList(ref pos, ref lexemes);
      }
   }
   
   // Анализ элемента для List. 
   private void ElementForList(ref int pos, ref List<Node> lexemes)
   {
      String(ref pos, ref lexemes);
      _str.First = lexemes[pos-1].Text;
      DoubleDot(ref pos, ref lexemes);
      _ = Object(ref pos, ref lexemes);
   }
   
   // Анализ значения поля, в случае, если он List<List>. 
   private void Dict(ref int pos, ref List<Node> lexemes)
   {
      OpSqBrack(ref pos, ref lexemes);
      if(lexemes[pos].Type != "ClSqBrack") BlocksForDict(ref pos, ref lexemes);
      ClSqBrack(ref pos, ref lexemes);
   }
   
   // Анализ блоков для List<List>. 
   private void BlocksForDict(ref int pos, ref List<Node> lexemes)
   {
      BlockForDict(ref pos, ref lexemes);
      _strListLists.Second.Add(_strLists.Second);
      _strLists = new Pair<string, List<Pair<string, string>>>();
      _strLists.Second = new List<Pair<string, string>>();
      NextBlockForDict(ref pos, ref lexemes);
   }
   
   // Самовызывающийся помощник для анализа блоков в случае, если List<List>. 
   private void NextBlockForDict(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         Comma(ref pos, ref lexemes);
         BlockForDict(ref pos, ref lexemes);
         _strListLists.Second.Add(_strLists.Second);
         NextBlockForDict(ref pos, ref lexemes);
      }
   }
   
   // Анализ блока для List<List>. 
   private void BlockForDict(ref int pos, ref List<Node> lexemes)
   {
      OpFigBrack(ref pos, ref lexemes);
      if(lexemes[pos].Type != "ClFigBrack") ElementsForDict(ref pos, ref lexemes);
      ClFigBrack(ref pos, ref lexemes);
   }
   
   // Анализ элементов для List<List>. 
   private void ElementsForDict(ref int pos, ref List<Node> lexemes)
   {
      ElementForDict(ref pos, ref lexemes);
      _strLists.Second.Add(_str);
      NextElementForDict(ref pos, ref lexemes);
   }
   
   // Самовызывающийся помощник для анализа элементов для List<List>. 
   private void NextElementForDict(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         Comma(ref pos, ref lexemes);
         ElementForDict(ref pos, ref lexemes);
         _strLists.Second.Add(_str);
         NextElementForDict(ref pos, ref lexemes);
      }
   }
   
   // Анализ элемента для List<List>. 
   private void ElementForDict(ref int pos, ref List<Node> lexemes)
   {
      String(ref pos, ref lexemes);
      _str.First = lexemes[pos-1].Text;
      DoubleDot(ref pos, ref lexemes);
      _ = Object(ref pos, ref lexemes);
   }
   
   // Анализ "{". 
   private static void OpFigBrack(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "OpFigBrack")
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная открывающая фигурная скобка");
   }
   
   // Анализ "}".
   private static void ClFigBrack(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "ClFigBrack")
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная закрывающая фигурная скобка");
   }
   
   // Анализ "[".
   private static void OpSqBrack(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "OpSqBrack") 
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная открывающая квадратная скобка");
   }
   
   // Анализ "]".
   private static void ClSqBrack(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "ClSqBrack")
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная закрывающая квадратная скобка");
   }
   
   // Анализ ":".
   private static void DoubleDot(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "DoubleDot")
      {
         pos+=1;
         return;
      }
      throw new Exception($"Неожиданное двоеточие");
   }
   
   // Анализ ",".
   private static void Comma(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "Comma")
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная запятая");
   }
   
   // Анализ для строки.
   private static void String(ref int pos, ref List<Node> lexemes)
   {
      if (lexemes[pos].Type == "String")
      {
         pos+=1;
         return;
      }
      throw new Exception("Неожиданная строка");
   }
}