namespace Project_mod3_Lib;

/// <summary>
/// Структура для хранения лексем. 
/// </summary>
public struct Node
{
   public string Text;
   public string Type;

   /// <summary>
   /// Оформленный вывод данных о Node (лексеме). 
   /// </summary>
   /// <returns></returns>
   public override string ToString()
   {
      return $"{Type}: {Text}";
   }
}

/// <summary>
/// Класс, реализующий обработку данных в json файлах. 
/// </summary>
public static class JsonParser
{
   /// <summary>
   /// Считывание данных из файлов json и их обработка. 
   /// </summary>
   /// <param name="path"> Путь к файлу для получения данных. </param>
   /// <param name="isFile"> Выбор пользователя (считывание из файла или из консоли). </param>
   /// <returns> Список всех обработанных элементов. </returns>
   public static List<Elem> ReadJson(string path, bool isFile = true)
   {
      if (isFile)
      {
         StreamReader reader = new StreamReader(path);
         string json = reader.ReadToEnd();
         SemanticParser parser = new SemanticParser();
         return parser.Parse(json);
      }
      else
      {
         SemanticParser parser = new SemanticParser();
         return parser.Parse(path);
      }
   }

   /// <summary>
   /// Запись данных в формате json. 
   /// </summary>
   /// <param name="path"> Путь к файлу для записи. </param>
   /// <param name="output"> Текст для вывода. </param>
   /// <param name="isFile"> Выбор пользователя для вывода (в файл или в консоль). </param>
   public static void WriteJson(string path, string output, bool isFile = true)
   {
      if (isFile)
      {
         StreamWriter writer = new StreamWriter(path);
         writer.Write(output);
         writer.Close(); // Закрытие потока. 
      }
      else
      {
         Console.Write(output);
      }
   }
}